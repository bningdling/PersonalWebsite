import { useConfigStyle, usePageInfo } from '@/layout/BasicLayout';
import { Button, Tabs } from 'antd';
import { useMemo, useState } from 'react';
import styles from './index.less';

const { TabPane } = Tabs;

export default () => {
    const pageInfo = usePageInfo();
    const configStyle = useConfigStyle();
    const allCategory = useMemo(() => {
        const result: string[] = ['All'];
        pageInfo.cards?.forEach(({ category }: { category: string[] }) => {
            category?.forEach((c) => {
                if (!result.includes(c)) {
                    result.push(c);
                }
            });
        });
        return result;
    }, [pageInfo.cards]);

    const [activeKey, setActiveKey] = useState('All');

    return (
        <div className={styles.wrapper}>
            <h2 style={configStyle.research.title}>{pageInfo.title}</h2>
            <Tabs activeKey={activeKey} onChange={setActiveKey}>
                {allCategory.map((c) => (
                    <TabPane tab={c} key={c}>
                        {pageInfo.cards
                            ?.filter((card: any) =>
                                c === 'All' ? true : card.category?.includes(c),
                            )
                            ?.map(
                                ({ title, subTitle, description, buttons }: any, index: number) => (
                                    <div className={styles.card} key={index}>
                                        <div
                                            style={configStyle.research.card.title}
                                            className={styles.title}
                                        >
                                            {title}
                                        </div>
                                        <div
                                            style={configStyle.research.card.subTitle}
                                            className={styles.subTitle}
                                        >
                                            {subTitle}
                                        </div>
                                        <p style={configStyle.research.card.description}>
                                            {description}
                                        </p>
                                        {buttons?.map((btn: any, btIndex: number) => (
                                            <Button
                                                key={btIndex}
                                                ghost
                                                type="primary"
                                                onClick={() => {
                                                    window.open(btn.target, '_blank');
                                                }}
                                                style={configStyle.research.card.buttons}
                                            >
                                                {btn.title}
                                            </Button>
                                        ))}
                                    </div>
                                ),
                            )}
                    </TabPane>
                ))}
            </Tabs>
        </div>
    );
};
