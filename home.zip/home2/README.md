# home

## 安装依赖

```shell
yarn
```

## 本地开发

```shell
yarn start
```

## 构建

```shell
yarn build
```
